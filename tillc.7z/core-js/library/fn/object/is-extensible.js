require('../../modules/es6.object.is-extensible');
module.exports = require('../../modules/_core').Object.isExtensible;
