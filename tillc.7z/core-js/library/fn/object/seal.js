require('../../modules/es6.object.seal');
module.exports = require('../../modules/_core').Object.seal;
