require('../../modules/es6.array.find');
module.exports = require('../../modules/_core').Array.find;
