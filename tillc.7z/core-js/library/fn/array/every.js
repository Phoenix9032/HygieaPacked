require('../../modules/es6.array.every');
module.exports = require('../../modules/_core').Array.every;
