require('../../modules/es6.typed.uint8-array');
module.exports = require('../../modules/_core').Uint8Array;
