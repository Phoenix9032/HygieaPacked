require('../../modules/es6.typed.int32-array');
module.exports = require('../../modules/_core').Int32Array;
