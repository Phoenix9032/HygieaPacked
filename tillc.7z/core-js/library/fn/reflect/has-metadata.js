require('../../modules/es7.reflect.has-metadata');
module.exports = require('../../modules/_core').Reflect.hasMetadata;
