require('../../../modules/es6.string.link');
module.exports = require('../../../modules/_entry-virtual')('String').link;
