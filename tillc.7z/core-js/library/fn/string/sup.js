require('../../modules/es6.string.sup');
module.exports = require('../../modules/_core').String.sup;
