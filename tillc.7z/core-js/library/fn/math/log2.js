require('../../modules/es6.math.log2');
module.exports = require('../../modules/_core').Math.log2;
